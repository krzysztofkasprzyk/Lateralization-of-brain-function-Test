# Test Lateralizacji - Web PsychoJS V2

To jest przeglądarkowa wersja testu lateralizacji TLDT / LDT przygotowana do uruchamiania w Google Chrome na Windows i macOS.

## Co to jest

Aplikacja wykorzystuje lokalne biblioteki `PsychoJS`, czyli webową bibliotekę z ekosystemu PsychoPy, do prezentacji bodźców i zbierania czasu reakcji w przeglądarce.

Program:

- wyświetla bodźce po lewej i prawej stronie punktu fiksacji,
- zbiera odpowiedzi klawiszami `F`, `J` i `Spacja`,
- prowadzi trening i część główną `256` prób,
- zapisuje dane do `CSV`,
- tworzy kopię awaryjną sesji w pamięci przeglądarki,
- pozwala zmieniać bodźce, parametry monitora i ustawienia debugowe.

## Jak uruchomić

1. Rozpakuj paczkę ZIP.
2. Uruchom plik [Test lateralizacji.html](C:\Private files\TestLP\WEB-psychoJS-FINAL\Test lateralizacji.html) w Google Chrome.

Najlepiej:

- nie uruchamiać pliku bezpośrednio z podglądu ZIP,
- używać Google Chrome,
- pozwolić aplikacji wejść w tryb pełnoekranowy przed testem.

## Jak działa test

1. Ustawiasz `ID uczestnika`, nazwę pliku CSV i parametry monitora.
2. Opcjonalnie wybierasz bezpośredni plik zapisu CSV w Chrome.
3. Uruchamiasz instrukcje, trening i część główną.
4. Po zakończeniu pobierasz `CSV` i w razie potrzeby `log`.

## Zapis danych

- Każdy badany może mieć osobny plik CSV.
- Domyślna nazwa pliku korzysta z `ID uczestnika` oraz czasu uruchomienia, żeby ograniczyć ryzyko nadpisania.
- Jeśli użytkownik nie wskaże bezpośredniego pliku zapisu, aplikacja nadal zachowa kopię awaryjną w przeglądarce i pozwoli pobrać CSV po zakończeniu.

## Uwaga metodologiczna

Przed badaniem trzeba potwierdzić:

- szerokość monitora w centymetrach,
- rozdzielczość monitora,
- refresh rate monitora.

Przeglądarka część z tych danych wykrywa automatycznie, ale wartości można też poprawić ręcznie w konfiguracji testu.
